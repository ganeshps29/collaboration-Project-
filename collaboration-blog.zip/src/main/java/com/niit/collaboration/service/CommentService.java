package com.niit.collaboration.service;

import com.niit.collaboration.domain.Comment;

/**
 * Provides comment-related operations
 */
public interface CommentService extends AbstractService<Comment> {

}
