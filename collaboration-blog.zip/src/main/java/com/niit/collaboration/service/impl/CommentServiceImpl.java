package com.niit.collaboration.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.collaboration.domain.Comment;
import com.niit.collaboration.repository.GenericRepository;
import com.niit.collaboration.service.CommentService;

@Service("CommentService")
public class CommentServiceImpl extends AbstractServiceImpl<Comment>
		implements CommentService {

	@Autowired
	public CommentServiceImpl(GenericRepository<Comment, Long> repository) {
		super(repository);
	}

}
