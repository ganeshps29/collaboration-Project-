package com.niit.collaboration.service.impl;

import static com.niit.collaboration.service.util.QueryParameters.setParam;

import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.collaboration.domain.Category;
import com.niit.collaboration.exception.ServiceException;
import com.niit.collaboration.repository.GenericRepository;
import com.niit.collaboration.service.CategoryService;

/**
 * Implementation of {@link CategoryService}
 */
@Service("CategoryService")
public class CategoryServiceImpl extends AbstractServiceImpl<Category>
		implements CategoryService {

	@Autowired
	public CategoryServiceImpl(GenericRepository<Category, Long> repository) {
		super(repository);
	}

	/**
	 * @see com.niit.collaboration.service.CategoryService#getByName(java.lang.String)
	 */
	@Override
	public Category getByName(String name) {
		try {
			return repository.getByNamedQuery("Category.GET_BY_NAME",
					setParam("name", name).buildMap());
		} catch (PersistenceException e) {
			String message = String.format("Unable to get category=%s", name);
			throw new ServiceException(message, e);
		}
	}
}
