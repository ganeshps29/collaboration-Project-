package com.niit.collaboration.service;

import com.niit.collaboration.domain.Category;

/**
 * Provides category-related operations
 */
public interface CategoryService extends AbstractService<Category> {
	
	/**
	 * Get category from repository by it's name
	 * 
	 * @param name category name
	 * @return category
	 */
	Category getByName(String name);
}
