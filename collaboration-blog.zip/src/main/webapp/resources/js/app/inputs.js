// Inputs maxlength control
$('input[maxlength]').maxlength();

$('input#news-title[maxlength], textarea[maxlength]').maxlength({threshold:20});
