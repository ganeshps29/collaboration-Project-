Collaboration
===========

Simple project using Spring MVC, Spring Security, Hibernate, Twitter Bootstrap

### How to run
1. mvn install
2. mvn tomcat7:run
3. http://localhost:8080/collaboration/

Available users: admin (admin), author (author), user (user)
