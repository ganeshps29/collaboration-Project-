package com.niit.bootstrapper.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;


@Configuration
@Import(MetricsConfiguration.class)
public class AppConfiguration {
}

